import greenfoot.*;

/**
 * Apple class is pretty boring. Most of the action can be found in the block class.
 * 
 * @author Eric Davis 
 * @version 1.0
 */
public class Apple extends Actor
{
    /**
     * Act - do whatever the Apple wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
